/*
 *Author:Kangruojin
 *Mail:mailbox_krj@163.com
 *Time:2017年7月16日13:39:34
 *Version:v1.3
 *
*/
#include "prime.h"

//create file of prime number
void PrimeNumberProduce(int num)
{
	/*primeNumber.txt 存放范围内的素数*/
	FILE * fp = fopen("primeNumber.txt","w");
	assert(NULL != fp);

	unsigned long start = 101, end = 1000;//从101开始，到1000*10^(num-2)结束，不包括end
	for(unsigned long i = 1; i<num-2; end *= 10, i++);

	/*找素数*/
	unsigned long k = 1, i = 0;
	while(start < end){
		if(true == isPrimeNumber(start)){
		//是素数，则写入文件，不是则直接goto判断下一个
			fprintf(fp,"%6lu: %-8lu",k,start);
			if(0 == k%5){
				fprintf(fp,"\n");
			}
			k++;	
		}
		start +=2;//+=1是偶数肯定不是素数，直接+=2判断奇数是不是素数
	}

	fclose(fp);
}

bool isPrimeNumber(unsigned long num)
{
	//num只判断奇数，而对i取余，i为偶数也就不需要判断
	//并且当判断到i=num/2时，还没有满足除了1和num自身的因子，就不会再有了，因为i>num/2时，结果必然为1.X
	//既然i>num/2时候存在该问题，那么i>num/3的时候便已经存在该问题了。这是1、2、3这三个素数的特殊性
	//即，num/i不可能为2（奇数num，不可能是奇数i的2倍），也不能为2.X；
	//综上：num/i不能为1，不能为1.X，不能为2，不能为2.x,但可能为3，i>num/3为结束条件
	//i=3;i<num;i++效率低下，修改如下：
	
	for(unsigned long i=3; i<=num/3; i += 2){
		if(0 == num % i){
			return false;
		}
	}
	return true;
}

int main(void)
{
	int num = 6;
	PrimeNumberProduce(num);
	return 0;
}

