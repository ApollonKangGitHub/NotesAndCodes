#ifndef _PRIME_H
#define _PRIME_H

#include <stdio.h>
#include <assert.h>

void PrimeNumberProduce(int);
bool isPrimeNumber(unsigned long);

#endif
