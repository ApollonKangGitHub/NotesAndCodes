#ifndef _ENCRYPT_DECRYPT_H
#define _ENCRYPT_DECRYPT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

//huge_t，所谓的大数据类型
typedef unsigned long huge_t;

//encryption key is public key
typedef struct RsaEncryptionKey{
	huge_t e;
	huge_t n;
}RsaEK;
//decryption key is private key
typedef struct RsaDecryptionKey{
	huge_t d;
	huge_t n;
}RsaDK;

void ErrorOfInput(const char *);
void RsaEncrypt(const char *, const char *);
void RsaDecrypt(const char *, const char *);
const huge_t ModExp(huge_t, huge_t, huge_t);

#endif
