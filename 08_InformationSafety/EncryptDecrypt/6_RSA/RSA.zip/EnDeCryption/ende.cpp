/*
 *Author:Kangruojin
 *Mail:mailbox_krj@163.com
 *Time:2017年7月16日13:39:00
 *Version:v1.1
 *
*/
#include "ende.h"

int main(int argc, char * argv[])
{
	if(argc != 4){
		ErrorOfInput(argv[0]);
		return 0;
	}

	//注意：这里只是测试，这种类似与CBC的分组加密方式是不适合于RSA的
	//RSA加密一般只有一组，即使有多组，也不应该采用CBC模式
	if(0 == strcmp(argv[1],"-e")){
		RsaEncrypt(argv[2], argv[3]);
	}
	else if(0 == strcmp(argv[1],"-d")){
		RsaDecrypt(argv[2],argv[3]);
	}
	else{
		ErrorOfInput(argv[0]);
	}
	return 0;
}
void ErrorOfInput(const char * str)
{
	printf("请按格式输入运行：\n");
	printf("%s -e 私钥e 私钥n\n",str);
	printf("%s -d 公钥d 公钥n\n",str);
}
void RsaEncrypt(const char *argv2, const char *argv3)
{
	huge_t ciphertext;
	unsigned char plaintext;
	RsaEK enk;
	enk.e = (huge_t)atol(argv2);
	enk.n = (huge_t)atol(argv3);

	FILE * fpin = fopen("./message/plaintext.txt","rb");
	FILE * fpout = fopen("./message/ciphertext.txt","wb");
	assert(fpin != NULL);	
	assert(fpout != NULL);
	
	fread(&plaintext, sizeof(plaintext), 1 ,fpin);//读取一个明文
	while(!feof(fpin)){
		//*ciphertext = plaintext^(enk->e) mod (enk->n)
		ciphertext = ModExp((huge_t)plaintext, enk.e, enk.n);//加密一个字符
		fwrite(&ciphertext, sizeof(ciphertext), 1, fpout);//写到秘文文件中
		fread(&plaintext, sizeof(plaintext), 1 ,fpin);//读取下一个明文
	}
	printf("加密结束！\n");
	
	fclose(fpin);
	fclose(fpout);
}
void RsaDecrypt(const char *argv2, const char *argv3)
{
	unsigned char plaintext,ciphertext;
	RsaDK dnk;
	dnk.d = (huge_t)atol(argv2);
	dnk.n = (huge_t)atol(argv3);

	FILE * fpin = fopen("./message/ciphertext.txt","rb");
	FILE * fpout = fopen("./message/plaintextNew.txt","wb");
	assert(fpin != NULL);	
	assert(fpout != NULL);
	
	fread(&ciphertext, sizeof(ciphertext), 1 ,fpin);//读取一个秘文
	while(!feof(fpin)){
		//*plaintext = ciphertext^(dnk->d mod (dnk->n)
		plaintext = ModExp((huge_t)ciphertext, dnk.d, dnk.n);//解密一个字符
		fwrite(&plaintext, sizeof(plaintext), 1, fpout);//写到明文文件中
		fseek(fpin, 3, SEEK_CUR);
		fread(&ciphertext, sizeof(ciphertext), 1 ,fpin);//读取下一个秘文
	}
	printf("解密结束！\n");
	
	fclose(fpin);
	fclose(fpout);
}
const huge_t ModExp(huge_t msg, huge_t exp, huge_t mod)
{
	#if 0
	//该算法效率太低
	huge_t resylt = 1;
	for(huge_t i = 0; i<exp; i++){
		result *= exp;
	}
	return result;
	#endif
	huge_t y =1;
	while(exp != 0){
		if(exp & 1){
			y = (y*msg) % mod;
		}
		msg = (msg*msg)%mod;
		exp = exp >> 1;
	}
	return y;
}
