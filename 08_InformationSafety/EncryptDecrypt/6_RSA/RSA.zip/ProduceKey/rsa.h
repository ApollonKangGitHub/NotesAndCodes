#ifndef _RSA_H
#define _RSA_H

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <time.h>


//huge_t，所谓的大数据类型
typedef unsigned long huge_t;

//encryption key is public key
typedef struct RsaEncryptionKey{
	huge_t e;
	huge_t n;
}RsaEK;
//decryption key is private key
typedef struct RsaDecryptionKey{
	huge_t d;
	huge_t n;
}RsaDK;

void rsa();
void CreatePublicKey(RsaEK *, huge_t, huge_t);
void CreatePrivateKey(RsaDK *, huge_t, huge_t, huge_t);
void RandomE(huge_t, huge_t &);
huge_t Inverses(huge_t, huge_t);

#endif
