/*
 *Author:Kangruojin
 *Mail:mailbox_krj@163.com
 *Time:2017年7月16日13:39:21
 *Version:v1.1
 *
*/
#include "rsa.h"

void rsa(void)
{
	huge_t p,q;//不可外泄
	while(1){
		system("clear");
		printf("请根据primeNumber.txt选择大的素数p:");
		scanf("%lu",&p);
		printf("请根据primeNumber.txt选择大的素数q:");
		scanf("%lu",&q);
		if(q < 10 || p < 10){
			printf("选择的数字太小不安全，请重新选择!");
		}else{
			break;
		}
	}

	RsaEK enk;
	RsaDK dnk;
	CreatePublicKey(&enk, p, q);
	CreatePrivateKey(&dnk, enk.e, p, q);
}
void CreatePublicKey(RsaEK * enk, huge_t p, huge_t q)
{
	FILE * fp = fopen("./key/encryption.key","w");
	assert(NULL != fp);
	
	enk->n = p*q;
	huge_t e;
	RandomE((p-1)*(q-1), e);
	enk->e = e;
	fprintf(fp,"e=%lu\nn=%lu",enk->e,enk->n);//写到公钥文件中，可以分享给通信另一方
	
	fclose(fp);
}
void CreatePrivateKey(RsaDK * dnk, huge_t e, huge_t p, huge_t q)
{
	FILE * fp = fopen("./key/decryption.key","w");
	assert(NULL != fp);
	
	dnk->n = p*q;
	dnk->d = Inverses((p-1)*(q-1),e);
	
	fprintf(fp,"d=%lu\nn=%lu",dnk->d,dnk->n);//写到私钥文件中，需要保密
	
	fclose(fp);
}
//随机产生一个数e(e<lcm)并判断该数是否与lcm互质
//不互质则重新产生
void RandomE(huge_t lcm, huge_t & e)
{
	huge_t x, y, r;
	srand(time(NULL));
	while(true){
		e = rand() % lcm;//e<lcm，且与lcm互质
		if(e>1){
			y = e;
			x = lcm;
			while(y != 1){
				r = x%y;
				x = y;
				y =r;
				if(y == 1 || y == 0){break;}
			}
			if(y == 1){break;}
		}	
	}	
}

//欧拉定理求d，求逆元算法
//根据欧拉函数φ和公钥e求解私钥d，满足(d*e) mod φ = 1
//φ=lcm[(p-1)*(q-1)],lcm即为least common multipe最小公倍数
huge_t Inverses(huge_t lcm, huge_t e)
{
	huge_t x1 = 1, x2 = 0, x3 = lcm;
	huge_t y1 = 0, y2 = 1, y3 = e;
	huge_t t1, t2, t3, temp;
	
	while(true){
		if(y3 == 1){
			return (y2 >= 0) ? (y2) : (y2+lcm);
		}	
		temp = x3/y3;
		t1 = x1 - temp * y1;
		t2 = x2 - temp * y2;
		t3 = x3 - temp * y3;
		x1 = y1;	x2 = y2;	x3 = y3;
		y1 = t1;	y2 = t2;	y3 = t3;
	}	
}
int main()
{
	system("clear");
	rsa();
	return 0;
}

