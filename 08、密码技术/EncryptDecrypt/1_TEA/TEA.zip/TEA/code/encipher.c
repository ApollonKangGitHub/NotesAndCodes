/*
 *Mode：ECB Mode
 *Author:Kangruojin
 *Mail:mailbox_krj@163.com
 *Time:2017年7月16日20:59:182
 *Version:v1.1
 *
*/

#include <stdio.h>
#include <string.h>

#define ROUNDS 32

void encipher(unsigned int msg[2],unsigned int key[4]);
void decipher(unsigned int msg[2],unsigned int key[4]);

int main(int argc, char * argv[])
{
	if(argc != 5){
		return 0;
	}

	char passwd[100] = {0};
	strcpy(passwd, argv[2]);
	FILE * fpin = fopen(argv[3],"rb");
	FILE * fpout = fopen(argv[4],"wb");

	if(fpin && fpout){
		unsigned int msg[2];
		while(!feof(fpin)){
			msg[0] = msg[1] = 0;
			if(fread(msg,1,8,fpin) == 0){
				break;
			}
			if(argv[1][0] == 'e'){
				encipher(msg,(unsigned int *)passwd);
			}else{	
				decipher(msg,(unsigned int *)passwd);
			}
			fwrite(msg,1,8,fpout);
		}
	}
	fclose(fpin);
	fclose(fpout);

	return 0;
}

void encipher(unsigned int msg[2],unsigned int key[4])
{
	unsigned int i;
	unsigned int msg0=msg[0],msg1=msg[1],sum=0,delta=0X9E3779B9;
	for(i=0; i<ROUNDS; i++){
		msg0 += (((msg1<<4) ^ (msg1>>5)) + msg1) ^ (sum + key[sum&3]);
		sum += delta;
		msg1 += (((msg0<<4) ^ (msg0>>5)) + msg0) ^ (sum + key[(sum>>11)&3]);
	}
	msg[0] = msg0;
	msg[1] = msg1;
}
void decipher(unsigned int msg[2],unsigned int key[4])
{
	unsigned int i;
	unsigned int msg0=msg[0],msg1=msg[1],delta=0X9E3779B9;
	unsigned int sum = delta * ROUNDS;

	for(i=0; i<ROUNDS; i++){
		msg1 -= (((msg0<<4) ^ (msg0>>5)) + msg0) ^ (sum + key[(sum>>11)&3]);
		sum -= delta;
		msg0 -= (((msg1<<4) ^ (msg1>>5)) + msg1) ^ (sum + key[sum&3]);
	}
	msg[0] = msg0;
	msg[1] = msg1;
}
