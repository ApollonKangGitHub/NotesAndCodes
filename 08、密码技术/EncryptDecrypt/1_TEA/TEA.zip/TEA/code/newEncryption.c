/*
 *Mode：CBC Mode
 *Author:Kangruojin
 *Mail:mailbox_krj@163.com
 *Time:2017年7月12日20:59:31
 *Version:v1.1
 *
*/
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

#define ROUNDS 32

void encipher(unsigned int msg[2],unsigned int key[4]);
void decipher(unsigned int msg[2],unsigned int key[4]);

int main(int argc, char * argv[])
{
	if(!((argc == 5 && argv[1][0] == 'e') || (argc == 7 && argv[1][0] == 'd'))){
		printf("Usage:%s e passwd inputFileName outputFileName\n",argv[0]);
		printf("Usage:%s d passwd inputFileName outputFileName iv_high_32bit iv_low_32bit\n",argv[0]);
		return 0;
	}

	unsigned int vi[2] = {0},tmp[2] = {0};
	if(argv[1][0] == 'e'){
		srand(time(NULL));
		vi[0] = rand();//rand()产生最大值为65535
		vi[1] = rand();

		printf("初始向量iv:%u(高32bit):%u(低32bit)\n",vi[1],vi[0]);
	}else if(argv[1][0] == 'd'){
		vi[1] = atoi(argv[5]);
		vi[0] = atoi(argv[6]);
	}

	char passwd[100] = {0};
	strcpy(passwd, argv[2]);
	FILE * fpin = fopen(argv[3],"rb");
	FILE * fpout = fopen(argv[4],"wb");

	if(fpin && fpout){
		unsigned int msg[2],i=0;
		while(!feof(fpin)){
			msg[0] = msg[1] = 0;
			if(fread(msg,1,8,fpin) == 0){
				break;
			}
			if(argv[1][0] == 'e'){
				msg[0] ^= vi[0];	msg[1] ^= vi[1];//明文与向量异或
				encipher(msg,(unsigned int *)passwd);//加密
				vi[0] = msg[0];		vi[1] = msg[1];//产生的秘文做新的向量
			}else{
				tmp[0] = msg[0];	tmp[1] = msg[1];//保存秘文
				decipher(msg,(unsigned int *)passwd);//解密
				msg[0] ^= vi[0];	msg[1] ^= vi[1];//解密后与向量异或得明文
				vi[0] = tmp[0]; 	vi[1] = tmp[1];//用上次解密的秘文做下一次的向量
			}
			fwrite(msg,1,8,fpout);
		}
	}
	fclose(fpin);
	fclose(fpout);

	return 0;
}

void encipher(unsigned int msg[2],unsigned int key[4])
{
	unsigned int i;
	unsigned int msg0=msg[0],msg1=msg[1],sum=0,delta=0X9E3779B9;
	for(i=0; i<ROUNDS; i++){
		msg0 += (((msg1<<4) ^ (msg1>>5)) + msg1) ^ (sum + key[sum&3]);
		sum += delta;
		msg1 += (((msg0<<4) ^ (msg0>>5)) + msg0) ^ (sum + key[(sum>>11)&3]);
	}
	msg[0] = msg0;
	msg[1] = msg1;
}
void decipher(unsigned int msg[2],unsigned int key[4])
{
	unsigned int i;
	unsigned int msg0=msg[0],msg1=msg[1],delta=0X9E3779B9;
	unsigned int sum = delta * ROUNDS;

	for(i=0; i<ROUNDS; i++){
		msg1 -= (((msg0<<4) ^ (msg0>>5)) + msg0) ^ (sum + key[(sum>>11)&3]);
		sum -= delta;
		msg0 -= (((msg1<<4) ^ (msg1>>5)) + msg1) ^ (sum + key[sum&3]);
	}
	msg[0] = msg0;
	msg[1] = msg1;
}
